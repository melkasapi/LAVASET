// GBCP.h
// #pragma once
#ifndef GBCP_H
#define GBCP_H
void GBCP(int M, int N, double* Labels, double* Data, int minleaf, int num_labels, double* bcvar, double* bcval);
#endif // GBCP_H
